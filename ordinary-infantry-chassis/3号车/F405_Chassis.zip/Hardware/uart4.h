#ifndef __UART4_H
#define __UART4_H

#define JudgeBufBiggestSize 45

void UART4_Configuration(void);
#endif
