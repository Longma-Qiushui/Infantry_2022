#ifndef _DAC_H
#define _DAC_H

void DAC1_Init(void);
void DAC1_Set_Vol(u16 vol);
void Dac1_Get_Vol(void);
void ChargeEnable(void);
#endif

