#ifndef __CAN2_H
#define __CAN2_H

void CAN2_Configuration(void);


#endif




