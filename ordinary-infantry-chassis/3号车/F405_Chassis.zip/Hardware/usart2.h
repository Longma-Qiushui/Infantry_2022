#ifndef _USART2_H_
#define _USART2_H_
#include "main.h"

 void USART2_Configuration(void);
#define RXTOF_USART2_BUFFER 40
#define TXTOF_USART2_BUFFER 20
#endif
