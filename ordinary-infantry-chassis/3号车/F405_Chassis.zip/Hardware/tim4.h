#ifndef __TIM4_H
#define __TIM4_H

#include "main.h"
#include "stm32f4xx_tim.h"

void TIM4_Configuration(void);



#endif
