#ifndef __STARTTASK_H
#define __STARTTASK_H

#include "main.h"

void CPU_task(void *pvParameters);
void start_task(void *pvParameters);

void startTast(void);


#endif
