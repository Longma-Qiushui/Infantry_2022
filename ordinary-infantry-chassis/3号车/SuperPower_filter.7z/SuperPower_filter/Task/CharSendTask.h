#ifndef __CHAR_SEND_H
#define __CHAR_SEND_H

void JudgementCustomizeChar(int Op_type);
void CharSendtask(void *pvParameters);
void referee_data_load_String(int Op_type);
int Char_Change_Check(void);
void Load_Char_Init(char Init_Flag);
#endif 
