#ifndef __TIM4_H
#define __TIM4_H

#include "main.h"
#include "stm32f10x_tim.h"

void TIM4_Configuration(void);



#endif
