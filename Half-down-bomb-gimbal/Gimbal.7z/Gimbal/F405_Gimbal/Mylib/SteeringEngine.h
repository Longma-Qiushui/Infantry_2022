#ifndef __STEERINGENGINE_H__
#define __STEERINGENGINE_H__

void SteeringEngine_Configuration(void);
void SteeringEngine_Set(int position);
#endif
