#ifndef __FRICTIONWHEEL_H__
#define __FRICTIONWHEEL_H__

void FrictionWheel_Configration(void);
void FrictionWheel_Set(short speed);

#endif
