#ifndef __TIM4_H__
#define __TIM4_H__

void Tim4_Configuration(void);

#endif 
