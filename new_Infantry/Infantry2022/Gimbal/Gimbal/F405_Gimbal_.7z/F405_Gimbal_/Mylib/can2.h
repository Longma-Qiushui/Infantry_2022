#ifndef __CAN2_H__
#define __CAN2_H__

void CAN2_Configuration(void);

#endif 
