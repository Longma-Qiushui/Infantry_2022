#ifndef __CAN_H__
#define __CAN_H__

void CAN1_Configuration(void);

#endif
