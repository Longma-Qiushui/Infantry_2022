#ifndef __TIM7_H
#define __TIM7_H

void TIM7_Configuration(void);

#endif
